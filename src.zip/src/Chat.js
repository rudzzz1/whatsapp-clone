import React from 'react'
import './Chat.css';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import { Avatar, IconButton } from "@mui/material"
import SearchOutlinedIcon from '@mui/icons-material/SearchOutlined';
import AttachFileIcon from '@mui/icons-material/AttachFile';
import InsertEmoticonIcon from '@mui/icons-material/InsertEmoticon';
import MicIcon from '@mui/icons-material/Mic';

function Chat({messages}) {
  return (
    <div className='chat'>
        <div className='chat__header'>
            <Avatar/> 
            <div className='chat__headerInfo'>
                <h3>Room name</h3>
                <p>Last seen ...</p>
            </div>

            <div className='chat__headerRight'>
                <IconButton>
                    <SearchOutlinedIcon/>
                </IconButton>
                <IconButton>
                    <AttachFileIcon/>
                </IconButton>
                <IconButton>
                    <MoreVertIcon/>
                </IconButton>
            </div>  
        </div>

        <div className='chat__body'>

            {
                messages.map((message) => (
                    <p className= {'chat__message ${message.received && "chat__reciever"}'}
                    >
                        <span className='chat__name'>{message.name}</span>
                        {message.message}
                        <span className='chat__timestamp'>
                            {message.timestamp}
                            </span>
                    </p>
                ))
            }
            

        </div>

        <div className='chat__footer'>
                <IconButton>
                    <InsertEmoticonIcon />
                </IconButton>

                <form> 
                    <input placeholder='Type a message' type = "text" />
                    <button type = "submit" > Send a message </button>
                </form>

                <IconButton>
                    <MicIcon />
                </IconButton>

        </div>
    </div>
  )
}

export default Chat