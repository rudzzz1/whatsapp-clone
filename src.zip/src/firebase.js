// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyDM2kqSFklfg237XJ8u_eBMWDAo8ntBmKk",
    authDomain: "reactfirst-bf0f9.firebaseapp.com",
    projectId: "reactfirst-bf0f9",
    storageBucket: "reactfirst-bf0f9.appspot.com",
    messagingSenderId: "290649104231",
    appId: "1:290649104231:web:65dc420bff029f57e099c2",
    measurementId: "G-PXXVED04T4"
  };